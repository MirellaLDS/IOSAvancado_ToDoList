//
//  UserTypeEnumeration.swift
//  MyFinalProject
//
//  Created by Halyson Ribeiro Pessoa on 13/01/2019.
//  Copyright © 2019 Halyson Ribeiro Pessoa. All rights reserved.
//

import Foundation

public enum UserTypeEnumeration{
    case Admin
    case View
    case Invalid
  
}
