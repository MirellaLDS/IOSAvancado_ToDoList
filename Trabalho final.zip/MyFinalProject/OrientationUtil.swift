//
//  OrientationUtil.swift
//  MyFinalProject
//
//  Created by Halyson Ribeiro Pessoa on 10/02/2019.
//  Copyright © 2019 Halyson Ribeiro Pessoa. All rights reserved.
//

import Foundation
import UIKit


struct OrientationUtil {
    
    static func lockOrientation(_ orientation: UIInterfaceOrientationMask) {
        
        if let delegate = UIApplication.shared.delegate as? AppDelegate {
            delegate.orientationLock = orientation
        }
    }
    
    /// OPTIONAL Added method to adjust lock and rotate to the desired orientation
    static func lockOrientation(_ orientation: UIInterfaceOrientationMask, andRotateTo rotateOrientation:UIInterfaceOrientation) {
        
        self.lockOrientation(orientation)
        
        UIDevice.current.setValue(rotateOrientation.rawValue, forKey: "orientation")
    }
    
}
